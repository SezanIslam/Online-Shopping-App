//
//  OnlineShopApp.swift
//  OnlineShop
//
//  Created by John Dela Cerna, Miguel Florendo, Sezan Islam and Haruki Abe on 12/17/22.
//

import SwiftUI

@main
struct OnlineShopApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
